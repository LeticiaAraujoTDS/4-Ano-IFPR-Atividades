<?php 

require_once __DIR__ . '/../app/core/Autoload.php';
require_once __DIR__ . '/../app/config/Config.php';

use app\core\Router;

$router = new Router();

$router->get('/', 'SiteController@index');
$router->get('/sobre', 'SiteController@about');
$router->get('/contato', 'SiteController@contact');

// Player Routes
$router->get('/jogadores', 'PlayerController@getAll');
$router->get('/jogadores/jogador', 'PlayerController@getJogador');
$router->get('/jogadores/cadastrar', 'PlayerController@createJogador');
$router->post('/jogadores/salvar', 'PlayerController@saveJogador');
$router->get('/jogadores/editar', 'PlayerController@editPlayer');
$router->post('/jogadores/atualizar', 'PlayerController@updatePlayer');
$router->get('/jogadores/excluir', 'PlayerController@deletePlayer');

$router->get('/teste', 'PlayerController@testeDatabase');


$router->run();