<?php

namespace app\repositories;

use app\database\ConnectionFactory;
use app\models\Player;

use PDO;

class JogadorRepository {
    private PDO $connection;

    function __construct() {
        $this->connection = ConnectionFactory::getConnection();
    }

    public function getJogadores() {

        $stm = $this->connection->prepare("SELECT * FROM players");
        $stm->execute();

        $jogadores= $stm->fetchAll();

        return $jogadores;
    }

    public function getJogador(int $id) {

        $stm = $this->connection->prepare("SELECT * FROM players WHERE id = :id");
        $stm->bindValue('id', $id);
        $stm->execute();

        $jogador = $stm->fetch();

        return $jogador;
    }

    public function saveJogador(Player $jogador) {

        $sql = "INSERT INTO players " .
               "(name, birthDate, nationality, height, weight, dominantFoot, position, team, image)" .
               "VALUES (:name, :nascimento, :nacionalidade, :altura, :peso, :peDominante, :posicao, :time, :imagem)";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(); //terminar na proxima aula;
    }
    
}