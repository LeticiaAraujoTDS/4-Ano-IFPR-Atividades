<?php

namespace app\services;
use app\repositories\JogadorRepository;

class JogadorService {
    private JogadorRepository $repository;

    public function __construct() {
        $this->repository = new JogadorRepository();
    }

    public function getJogadores () {
        // se houver necessidade de uma validação ou verificação, aqui é onde deve ser implementado!!!
        return $this->repository->getJogadores();
    }

    public function getJogador(int $id) {
        
        return $this->repository->getJogador($id);
    }

    public function saveJogador(Player $jogador) {
        
        return $this->repository->saveJogador($jogador);
    }

}