<?php 
namespace app\controllers;

use DateTimeImmutable;
use app\core\Controller;
use app\models\Player;
use app\services\JogadorService;

class PlayerController extends Controller {

    private JogadorService $service;

    public function __construct()
    {
        $this->service = new JogadorService();
    }

    public function getAll() {

        $data['list'] = $this->service->getJogadores();
        $this->view('players/players_list', $data);
    }

    public function getJogador(){

        if (!isset($_GET['id'])) {
            $this->redirect(URL_BASE . '/jogadores');
        }

        $id = $_GET['id'];

        $data['jogador'] = $this->service->getJogador($id);

        $this->view('players/players_show', $data);

    }

    public function createJogador(){
        $this->view('players/players_create', []);
    }

    public function saveJogador(){

        $nome = $_POST['name'];
        $nascimento = $_POST['birthDate'];
        $nacionalidade = $_POST['nationality'];
        $altura = $_POST['height'];
        $peso = $_POST['weight'];
        $peDominante = $_POST['dominantFoot'];
        $posicao = $_POST['position'];
        $time = $_POST['team'];
        $image = $_POST['image'];

        $jogador = new Player();

        $jogador->setName($nome);
        $jogador->setBirthDate($nascimento);
        $jogador->setNationality($nacionalidade);
        $jogador->setHeight($altura);
        $jogador->setWeight($peso);
        $jogador->setDominantFoot($peDominante);
        $jogador->setPosition($posicao);
        $jogador->setTeam($time);
        $jogador->setImage($image);

        $this->service->saveJogador($jogador);
    }

    public function testRedirect(){
        $this->redirect("http://google.com");
    }

} 